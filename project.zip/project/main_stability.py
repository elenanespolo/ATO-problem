import gurobipy as gp # type: ignore
import pandas as pd # type: ignore
from gurobipy import GRB # type: ignore
import numpy as np # type: ignore
from model import gurobi_model # type: ignore
from scipy.stats import norm # type: ignore

def compute_in_sample_stability(starting_n_scenario:int = 2, max_iterations:int=50, step_iteration:int = 1, df1:pd.DataFrame = None, products_price:dict = None, machine_daily_time:dict = None):
    #
    # This function computes the in-sample stability analysis for the ATO problem with stochastic demand
    #
    # ATTENTION: the function stops as soon as a model is not feasible
    #
    # INPUTS:
    # starting_n_scenario: initial number of scenarios
    # max_iterations: maximum number of iterations
    # step_iteration: increment in the number of scenarios
    # df1: dataframe with n_components rows and (n_machines + n_products +1) columns.
    #   The first n_machines columns are the time in minutes that each component takes in each machine.
    #   The next n_products columns are the gozinto factors for each component.
    #   The last column is the fixed cost of each component.
    # products_price: dictionary with the price of each product
    # machine_daily_time: dictionary with the daily time in minutes available for each machine
    #
    # OUTPUT:
    # n_scenario: when the CLT conditions are satisfied number of scenarios 
    #   otherwise 'No scenario satisfies the CLT conditions' or
    #   'Model not feasible' if the model is not feasible
    # stability_diff_dict: dictionary with the stability difference for each number of scenarios
    #  


    if products_price == None:
        num_items = 2
    else:
        num_items = len(products_price)
    n_scenario = starting_n_scenario

    stability_diff_dict = {}
    for iteration in range(max_iterations):
        # Generate two independent sets of scenarios S1 and S2 with cardinality n_scenario
        np.random.seed(42*iteration)
        demand_S1 =  np.random.normal(loc=100, scale=40, size=(n_scenario, num_items)).astype(int)
        demand_S1 = np.clip(demand_S1, 0, None) # Check no values are negative

        np.random.seed(84*iteration+1)
        demand_S2 = np.random.normal(loc=100, scale=40, size=(n_scenario, num_items)).astype(int)
        demand_S2 = np.clip(demand_S2, 0, None)

        # Solve the stochastic models for S1 and S2
        modelS1 = gurobi_model(demand=demand_S1)
        modelS2 = gurobi_model(demand=demand_S2)
        
        if modelS1 is None or modelS2 is None:
            return ('Model not feasible', stability_diff_dict)
        # Compute the stability difference
        stability_diff = abs(modelS1.objVal - modelS2.objVal)
        stability_diff_dict[n_scenario] = stability_diff
        
        n_scenario += step_iteration
    
    mu = np.mean(list(stability_diff_dict.values()))
    sigma = np.std(list(stability_diff_dict.values()))
    alpha = 0.05
    z_alpha = norm.ppf(1 - alpha / 2)
    print(f'Mean = {mu}, Standard Deviation = {sigma}, z_alpha = {z_alpha}')
    for key, value in stability_diff_dict.items():
        if value < mu + z_alpha*sigma/np.sqrt(max_iterations) or stability_diff_dict[key] < mu - z_alpha*sigma/np.sqrt(max_iterations):
            return (key, stability_diff_dict)

    return ('No scenario satisfies the CLT conditions', stability_diff_dict)

def compute_out_sample_stability(starting_n_scenario:int = 2, big_n_scenario:int = 55, stability_tolerance:float=1e-2, max_iterations:int=50, step_iteration:int = 1, df1:pd.DataFrame = None, products_price:dict = None, machine_daily_time:dict = None) -> int:
    #
    # This function computes the out-of-sample stability analysis for the ATO problem with stochastic demand
    #
    # ATTENTION: the function stops as soon as a model is not feasible
    #
    # INPUTS:
    # starting_n_scenario: initial number of scenarios
    # max_iterations: maximum number of iterations
    # step_iteration: increment in the number of scenarios
    # df1: dataframe with n_components rows and (n_machines + n_products +1) columns.
    #   The first n_machines columns are the time in minutes that each component takes in each machine.
    #   The next n_products columns are the gozinto factors for each component.
    #   The last column is the fixed cost of each component.
    # products_price: dictionary with the price of each product
    # machine_daily_time: dictionary with the daily time in minutes available for each machine
    #
    # OUTPUT:
    # n_scenario: when the CLT conditions are satisfied number of scenarios 
    #   otherwise 'No scenario satisfies the CLT conditions' or
    #   'Model not feasible' if the model is not feasible
    # stability_diff_dict: dictionary with the stability difference for each number of scenarios
    #  
    
    if products_price == None:
        num_items = 2
    else:
        num_items = len(products_price)
    n_scenario = starting_n_scenario

    stability_diff_dict = {}
    np.random.seed(1)
    demand_bigN = np.random.normal(loc=100, scale=40, size=(big_n_scenario, num_items)).astype(int)
    demand_bigN = np.clip(demand_bigN, 0, None)
    model_bigN = gurobi_model(demand=demand_bigN)
    objVal_bigN = model_bigN.objVal
    for iteration in range(max_iterations):
        # Generate scenario S1 with cardinality n_scenario
        np.random.seed(42*iteration)
        demand_S1 = np.random.normal(loc=100, scale=40, size=(n_scenario, num_items)).astype(int)
        demand_S1 = np.clip(demand_S1, 0, None)

        # Solve the stochastic model for S1
        modelS1 = gurobi_model(demand=demand_S1)
        
        if modelS1 is None:
            return (n_scenario, 'Model not feasible', stability_diff_dict)
        # Compute the stability difference
        stability_diff = abs(modelS1.objVal - objVal_bigN)
        stability_diff_dict[n_scenario] = stability_diff
        
        # Check if the stability difference is within the tolerance
        if stability_diff < stability_tolerance:
            break
        else:
            n_scenario += step_iteration

    return (n_scenario, stability_diff, stability_diff_dict)

# Perform In-Sample Stability Analysis
n_scenario_in_sample, stability_dict_in_sample = compute_in_sample_stability()
stability_dict_in_sample = dict(sorted(stability_dict_in_sample.items(), key=lambda x: x[1], reverse=False))

# Perform Out-of-Sample Stability Analysis
n_scenario_out_sample, stability_diff_out_sample, stability_dict_out_sample = compute_out_sample_stability()
stability_dict_out_sample = dict(sorted(stability_dict_out_sample.items(), key=lambda x: x[1], reverse=False))

print(' ')
print('In-Sample Stability Analysis')
if n_scenario_in_sample == 'Model not feasible':
    print(f'Model not feasible')
elif n_scenario_in_sample == 'No scenario satisfies the CLT conditions':
    print(f'No scenario satisfies the CLT conditions')
else:
    print(f'In-Sample Stability achieved with {n_scenario_in_sample} scenarios and stability difference = {stability_dict_in_sample[n_scenario_in_sample]}')
print('The differences in the objective function value for different scenarios are:')
for key, value in stability_dict_in_sample.items():
    print(f'n_scenario = {key}, stability difference = {value}')
print(' ')
print('Out-of-Sample Stability Analysis')
if stability_diff_out_sample == 'Model not feasible':
    print(f'Model not feasible with {n_scenario_out_sample} scenarios')
else:
    print(f'Out-of-Sample Stability achieved with {n_scenario_out_sample} scenarios and stability difference = {stability_diff_out_sample}')
print('The differences in the objective function value for different scenarios are:')
for key, value in stability_dict_out_sample.items():
    print(f'n_scenario = {key}, stability difference = {value}')
